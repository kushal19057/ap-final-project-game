package application;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;

public class Game {
    private int currentScore;
    private int highScore;
    
    private ScoreLabel scoreLabel;
    private ScoreLabel highScoreLabel;
    
    private Stage menuStage;
    
    private AnchorPane gamePane;
    private Scene gameScene;
    private Stage gameStage;
    
    
    
    private PauseMenu pauseMenuManager;
    
    private int yStep;
    private Circle ball;    
    private int centerX;
    private int radius;
    private double currentPosition;
    private double currentVelocity;
    
    private Timeline loop;

    public Game() {
        initStage();
        initBall();
        initLabel();
        
        createKeyListener();
        createBackground();
        
        startGame();
    }
    
    
    
    private void initLabel() {
    	scoreLabel = new ScoreLabel("POINTS: 00");
        scoreLabel.setLayoutX(20);
        scoreLabel.setLayoutY(20);
        highScoreLabel = new ScoreLabel("HIGHEST: 100");
        highScoreLabel.setLayoutY(20);
        highScoreLabel.setLayoutX(Constants.GAME_WIDTH - 270);
        gamePane.getChildren().addAll(scoreLabel, highScoreLabel);
    }
    
    private void initBall() {
    	this.centerX = 384;
    	this.currentPosition = 600;
        this.radius = 50;
        this.currentVelocity = 0;
        this.ball = new Circle(centerX, currentPosition, radius, Color.LIGHTSKYBLUE);
        gamePane.getChildren().add(ball);
    }

    private void startGame() {
    	yStep = 20;
        this.loop = new Timeline(new KeyFrame(Duration.millis(Constants.UPDATE_PERIOD), evt-> {
        	currentPosition += yStep;
    		if(currentPosition + radius > Constants.GAME_HEIGHT || currentPosition - radius < 0) {
    			yStep = -yStep;
    		}
    		ball.setCenterY(currentPosition);
        }));

        loop.setCycleCount(Timeline.INDEFINITE);
        loop.play();
    }
    

    private void initStage() {
        this.gamePane = new AnchorPane();
        this.gameScene = new Scene(gamePane, Constants.GAME_WIDTH, Constants.GAME_HEIGHT);
        gameStage = new Stage();
        gameStage.setScene(gameScene);
    }

    public void createNewGame(Stage menuStage) {
        this.menuStage = menuStage;
        gameStage.initModality(Modality.APPLICATION_MODAL);
        gameStage.setTitle("Color Switch");
        gameStage.show();
    }

    private void createKeyListener() {
        gameScene.setOnKeyPressed(new EventHandler<KeyEvent>() {
            @Override
            public void handle(KeyEvent keyEvent) {
                if( keyEvent.getCode() == KeyCode.SPACE) {
                    System.out.println("Space bar pressed");
                    yStep *= -1;
                    // jump the idiotic ball
                    //currentVelocity = Constants.VELOCITY_JUMP;
                }
                if( keyEvent.getCode() == KeyCode.P) {
                	pauseMenuManager = new PauseMenu(gameStage);
                    System.out.println("pause pressed");
                    //loop.pause();
                    // halt the game
                }
				/*
				 * if(keyEvent.getCode() == KeyCode.R) { System.out.println("resume");
				 * loop.play(); }
				 */
                if( keyEvent.getCode() == KeyCode.G) {
                	System.out.println("game over");
                }
            }
        });
    }

    private void createBackground() {
        Image backgroundImage = new Image("resources/black.png", 256, 256, false, true);
        BackgroundImage background = new BackgroundImage(backgroundImage, BackgroundRepeat.REPEAT, BackgroundRepeat.REPEAT, BackgroundPosition.DEFAULT, null);
        gamePane.setBackground(new Background(background));
    }
}