package application;

public class Fruit {

}
