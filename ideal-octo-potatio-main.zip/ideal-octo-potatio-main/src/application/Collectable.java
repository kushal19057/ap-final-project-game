package application;

public interface Collectable {

}
