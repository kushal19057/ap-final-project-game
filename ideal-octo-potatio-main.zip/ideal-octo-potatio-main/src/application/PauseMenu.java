package application;

import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import java.util.List;
import java.util.ArrayList;

public class PauseMenu {
	private Stage pauseMenuStage;
    private Scene pauseMenuScene;
    private AnchorPane pauseMenuPane;
    
    private List<ColorSwitchButton> pauseMenuButtons;
    
	public PauseMenu(Stage gameStage) {
		initPauseMenuStage();
		pauseMenuStage.show();
		pauseMenuButtons = new ArrayList<>();
		createButtons();
		createBackground();
		createLogo();
		
	}
	
	private void createButtons() {
		createResumeButton();
		createSaveButton();
		createSaveAndBackToMainMenuButton();
		createExitWithoutSavingButton();
	}
	
	private void createResumeButton() {
		ColorSwitchButton resumeButton = new ColorSwitchButton("RESUME GAME");
		addPauseMenuButton(resumeButton);
	}
	
	private void createSaveButton() {
		ColorSwitchButton saveButton = new ColorSwitchButton("SAVE GAME");
		addPauseMenuButton(saveButton);
	}
	
	private void createSaveAndBackToMainMenuButton() {
		ColorSwitchButton saveAndBackToMainMenuButton = new ColorSwitchButton("TO MAIN MENU");
		addPauseMenuButton(saveAndBackToMainMenuButton);
	}
	
	private void createExitWithoutSavingButton() {
		ColorSwitchButton exitWithoutSavingButton = new ColorSwitchButton("EXIT GAME");
		addPauseMenuButton(exitWithoutSavingButton);
	}
	
	private void initPauseMenuStage() {
    	pauseMenuPane = new AnchorPane();
    	pauseMenuScene = new Scene(pauseMenuPane, Constants.MAIN_MENU_OPTION_WIDTH, Constants.MAIN_MENU_OPTION_HEIGHT);
    	pauseMenuStage = new Stage();
    	pauseMenuStage.setTitle("Pause Menu");
    	pauseMenuStage.setScene(pauseMenuScene);
    	pauseMenuStage.initModality(Modality.APPLICATION_MODAL);
    	pauseMenuStage.initStyle(StageStyle.UTILITY);
    }
	
	private void addPauseMenuButton(ColorSwitchButton button) {
        button.setLayoutX(Constants.MENU_BUTTONS_START_X - 110);
        button.setLayoutY(Constants.MENU_BUTTONS_START_Y - 50 + pauseMenuButtons.size() * 100);
        pauseMenuButtons.add(button);
        pauseMenuPane.getChildren().add(button);
    }
	
    private void createBackground() {
        Image backgroundImage = new Image("resources/deep_blue.png", 256, 256, false, true);
        BackgroundImage background = new BackgroundImage(backgroundImage, BackgroundRepeat.REPEAT, BackgroundRepeat.REPEAT, BackgroundPosition.DEFAULT, null);
        pauseMenuPane.setBackground(new Background(background));
    }

    private void createLogo() {
        ImageView logo = new ImageView("resources/colorswitchlogo.png");
        logo.setLayoutX(65);
        logo.setLayoutY(30);
        pauseMenuPane.getChildren().add(logo);
    }
	
}

/*

 * 
 * private void createButtons() { createSaveAndReturn(); createRestartGame();
 * createReturntoGame(); createSaveAndExit(); }
 * 
 * private void createSaveAndReturn() { ColorSwitchButton startButton = new
 * ColorSwitchButton("SAVE & RETURN TO MAIN MENU");
 * addMenuButton(SaveAndReturnButton);
 * 
 * startButton.setOnAction(new EventHandler<ActionEvent>() {
 * 
 * @Override public void handle(ActionEvent actionEvent) { //CODE FOR SAVING IS
 * REQUIRED. CODE TO RETURN IS REQUIRED SINCE IT IS DIFFERENT FROM Starting a
 * new game. pauseMenuStage.hide(); //playing = true; gameStage.show();
 * //returnToGame(); startGame(); } }); }
 * 
 * private void createRestartGame() { ColorSwitchButton RestartGameButton = new
 * ColorSwitchButton("RESTART GAME"); addMenuButton(RestartGameButton);
 * 
 * loadGameButton.setOnAction(new EventHandler<ActionEvent>() {
 * 
 * @Override public void handle(ActionEvent actionEvent) { GameStage.show();
 * startGame(); } }); }
 * 
 * private void createReturntoGame() { ColorSwitchButton helpButton = new
 * ColorSwitchButton("RETURN TO GAME"); addMenuButton(ReturntoGameButton);
 * 
 * helpButton.setOnAction(new EventHandler<ActionEvent>() {
 * 
 * @Override public void handle(ActionEvent actionEvent) {
 * pauseMenuStage.hide(); } }); }
 * 
 * private void createSaveAndExitButton() { ColorSwitchButton exitButton = new
 * ColorSwitchButton("SAVE AND EXIT"); addMenuButton(exitButton);
 * 
 * exitButton.setOnAction(new EventHandler<ActionEvent>() {
 * 
 * @Override //CODE FOR SAVING THE GAME? public void handle(ActionEvent
 * actionEvent) { PauseMenuStage.close(); } }); }
 * 
 * private void addMenuButton(ColorSwitchButton button) {
 * button.setLayoutX(Constants.MENU_BUTTONS_START_X);
 * button.setLayoutY(Constants.MENU_BUTTONS_START_Y + menuButtons.size() * 100);
 * menuButtons.add(button); mainMenuPane.getChildren().add(button); }
 * 

 */