package application;

public class ColorShuffler {

}
